import 'vue-router'

import type { UserRole } from '@/types/auth'

export type RouteAccess = 'public' | 'guest' | 'authenticated'

declare module 'vue-router' {
  interface RouteMeta {
    /**
     * 顯示於瀏覽器頁籤的頁面名稱。
     */
    title?: string

    /**
     * public：任何人皆可進入（預設）
     * guest：僅限未登入訪客
     * authenticated：必須登入
     */
    access?: RouteAccess

    /**
     * 允許進入頁面的角色。設定 roles 時，頁面也會自動要求登入。
     */
    roles?: readonly UserRole[]
  }
}

export {}
