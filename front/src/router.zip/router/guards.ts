import type { Router } from 'vue-router'
import { START_LOCATION } from 'vue-router'

import { useRefreshMutation } from '@/quries/auth'
import { useUserStore } from '@/stores/user'

import type { UserRole } from './meta'

let isAuthInitialized = false

function hasRequiredRole(
  requiredRoles: readonly UserRole[] | undefined,
  userRoles: readonly UserRole[],
): boolean {
  if (!requiredRoles?.length) {
    return true
  }

  return requiredRoles.some(role =>
    userRoles.includes(role),
  )
}

export function setupRouterGuards(router: Router): void {
  router.beforeEach(async (to, from) => {
    if (
      from === START_LOCATION &&
      !isAuthInitialized
    ) {
      isAuthInitialized = true

      try {
        await useRefreshMutation().mutateAsync()
      } catch {
        // 沒有有效登入狀態時，繼續執行路由權限判斷。
      }
    }

    const user = useUserStore()

    switch (to.meta.access) {
      case 'guest':
        if (user.isLoggedIn) {
          return {
            name: 'home',
          }
        }

        break

      case 'authenticated':
        if (!user.isLoggedIn) {
          return {
            name: 'login',
            query: {
              redirect: to.fullPath,
            },
          }
        }

        break

      case 'public':
      default:
        break
    }

    if (
      !hasRequiredRole(
        to.meta.roles,
        user.roles,
      )
    ) {
      return {
        name: 'forbidden',
      }
    }

    return true
  })
}
